var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
var offsetwidth = 0;
Page({
  data: {
    tabs: ["验证", "填写", "确认", "提交"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    IDcard:"",
    phoneNumber:"",
    verifyCode:""
  },
  onLoad: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
        offsetwidth = res.windowWidth / that.data.tabs.length;
      }
    });
  },
   nextClick: function (e) {
     var index = this.data.activeIndex;
     switch(index){
      case 0:
        if(!firstVerify()){
          return;
        }
      break;
     }
    gotoNextTab(e);
  }, preClick: function (e) {
    gotoPreTab(e);
  },
  IDcardInput:function(e){
    this.setData({
      IDcard: e.detail.value
    })
  },
  phoneNumberInput: function (e) {
    this.setData({
      phoneNumber: e.detail.value
    })
  }, 
  verifyCodeInput:function(e){
    this.setData({
      verifyCode: e.detail.value
    })
  }
});
//下一步
function gotoNextTab(e) {
  var that = getCurrentPages()[getCurrentPages().length - 1];
  that.data.activeIndex++;
  that.setData({
    sliderOffset: that.data.activeIndex * offsetwidth,
    activeIndex: that.data.activeIndex
  });
};
//上一步
function gotoPreTab(e) {
  var that = getCurrentPages()[getCurrentPages().length - 1];
  that.data.activeIndex--;
  that.setData({
    sliderOffset: that.data.activeIndex * offsetwidth,
    activeIndex: that.data.activeIndex
  });
}
// 验证身份证号是否合法
function isIDcardNo(s){
  var isIDCard1 = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$/; 
  var isIDCard2 = /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
  if(s!=null){
    if(s.length == 15 && isIDCard1.test(s)){
      return true;
    }else if(s.length == 18 && isIDCard2.test(s)){
      return true;
    }else{
      return false;
    }
  }
}
function isPhoneNum(s){
  if(s !=null && s.length == 4){
    return true;
  }else{
    return false;
  }
}
function firstVerify(){
  var that = getCurrentPages()[getCurrentPages().length - 1];
  var IDcard = that.data.IDcard;
  var phoneNumer = that.data.phoneNumber;
  var verifyCode = that.data.verifyCode;
  if (IDcard === "") {
    wx.showToast({
      title: "请输入身份证号"
    });
    return false;
  } else if (!isIDcardNo(IDcard)) {
    wx.showToast({
      title: "请输入合法的身份证号"
    });
    return false;
  } else if (phoneNumer === "") {
    wx.showToast({
      title: "请输入手机后四位"
    });
    return false;
  } else if (!isPhoneNum(phoneNumer)) {
    wx.showToast({
      title: "请输入完整的手机后四位"
    });
    return false;
  } else if (verifyCode === "") {
    wx.showToast({
      title: "请输入验证码"
    });
    return false;
  } else {
    console.log("身份证号:" + IDcard + " 手机后四位:" + phoneNumer + " 验证码:" + verifyCode);
    return true;
  }
}